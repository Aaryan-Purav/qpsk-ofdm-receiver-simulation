"""
OFDM Engine - Connects QPSK to LTE/5G context
"""
import numpy as np

class OFDMSystem:
    """OFDM modulation system"""
    
    def __init__(self, n_subcarriers=64, cp_length=16, 
                 pilot_spacing=4, pilot_power=1.0):
        """
        Initialize OFDM system
        
        Args:
            n_subcarriers: Number of subcarriers (FFT size)
            cp_length: Cyclic prefix length
            pilot_spacing: Spacing between pilot subcarriers
            pilot_power: Pilot symbol power
        """
        self.N = n_subcarriers
        self.cp_len = cp_length
        self.pilot_spacing = pilot_spacing
        self.pilot_power = pilot_power
        
        # Define pilot positions
        self.pilot_indices = np.arange(0, n_subcarriers, pilot_spacing)
        self.data_indices = np.setdiff1d(np.arange(n_subcarriers), 
                                         self.pilot_indices)
    
    def generate_pilots(self):
        """Generate QPSK pilot symbols"""
        n_pilots = len(self.pilot_indices)
        # Fixed QPSK pilots for channel estimation
        pilots = np.array([1+1j, 1-1j, -1-1j, -1+1j]) / np.sqrt(2)
        pilots = np.tile(pilots, n_pilots // 4 + 1)[:n_pilots]
        pilots = pilots * np.sqrt(self.pilot_power)
        
        return pilots
    
    def ofdm_modulate(self, qpsk_symbols):
        """
        OFDM modulation
        
        Args:
            qpsk_symbols: Data symbols (QPSK)
        
        Returns:
            OFDM time-domain signal
        """
        # Map symbols to subcarriers
        ofdm_symbol = np.zeros(self.N, dtype=complex)
        
        # Insert pilots
        pilots = self.generate_pilots()
        ofdm_symbol[self.pilot_indices] = pilots
        
        # Insert data
        n_data_subcarriers = len(self.data_indices)
        if len(qpsk_symbols) < n_data_subcarriers:
            qpsk_symbols = np.pad(qpsk_symbols, 
                                 (0, n_data_subcarriers - len(qpsk_symbols)))
        
        ofdm_symbol[self.data_indices] = qpsk_symbols[:n_data_subcarriers]
        
        # IFFT
        time_signal = np.fft.ifft(ofdm_symbol) * np.sqrt(self.N)
        
        # Add cyclic prefix
        cp = time_signal[-self.cp_len:]
        ofdm_with_cp = np.concatenate([cp, time_signal])
        
        return ofdm_with_cp, pilots
    
    def ofdm_demodulate(self, rx_signal):
        """
        OFDM demodulation
        
        Args:
            rx_signal: Received time-domain signal
        
        Returns:
            Received symbols, pilot estimates
        """
        # Remove cyclic prefix
        rx_no_cp = rx_signal[self.cp_len:]
        
        # FFT
        freq_signal = np.fft.fft(rx_no_cp) / np.sqrt(self.N)
        
        # Extract pilots and data
        rx_pilots = freq_signal[self.pilot_indices]
        rx_data = freq_signal[self.data_indices]
        
        return rx_data, rx_pilots
    
    def estimate_channel_ofdm(self, rx_pilots):
        """
        Estimate channel using pilots
        
        Args:
            rx_pilots: Received pilot symbols
        
        Returns:
            Channel estimate for all subcarriers
        """
        from channel_estimation import ChannelEstimator
        
        tx_pilots = self.generate_pilots()
        
        # LS estimation at pilots
        H_pilots = ChannelEstimator.least_squares(rx_pilots, tx_pilots)
        
        # Interpolate to all subcarriers
        H_full = ChannelEstimator.interpolate_channel(
            H_pilots, self.pilot_indices, np.arange(self.N)
        )
        
        return H_full
    
    def equalize_ofdm(self, rx_data, H_data):
        """
        Equalize OFDM data subcarriers
        
        Args:
            rx_data: Received data symbols
            H_data: Channel estimate at data positions
        
        Returns:
            Equalized symbols
        """
        # Zero-forcing equalization in frequency domain
        H_safe = np.where(np.abs(H_data) < 1e-10, 1e-10, H_data)
        equalized = rx_data / H_safe
        
        return equalized


class LTEFrame:
    """LTE Frame Structure"""
    
    def __init__(self):
        """Initialize LTE parameters"""
        # LTE parameters (simplified)
        self.subcarrier_spacing = 15e3  # Hz
        self.n_rb = 50  # Number of resource blocks (10 MHz bandwidth)
        self.n_sc_per_rb = 12  # Subcarriers per RB
        self.n_symbols_per_slot = 7  # OFDM symbols per slot
        self.n_slots_per_subframe = 2
        
        self.total_subcarriers = self.n_rb * self.n_sc_per_rb
    
    def create_resource_grid(self):
        """
        Create LTE resource grid
        
        Returns:
            Resource grid (subcarriers x OFDM symbols)
        """
        n_symbols = self.n_symbols_per_slot * self.n_slots_per_subframe
        grid = np.zeros((self.total_subcarriers, n_symbols), dtype=complex)
        
        return grid
    
    def map_qpsk_to_grid(self, qpsk_symbols, grid):
        """
        Map QPSK symbols to resource grid
        
        Args:
            qpsk_symbols: QPSK modulated data
            grid: Resource grid
        
        Returns:
            Filled grid
        """
        # Simple mapping (actual LTE has complex rules)
        flat_grid = grid.flatten()
        n_available = len(flat_grid)
        
        if len(qpsk_symbols) > n_available:
            qpsk_symbols = qpsk_symbols[:n_available]
        else:
            qpsk_symbols = np.pad(qpsk_symbols, 
                                 (0, n_available - len(qpsk_symbols)))
        
        filled_grid = qpsk_symbols.reshape(grid.shape)
        
        return filled_grid