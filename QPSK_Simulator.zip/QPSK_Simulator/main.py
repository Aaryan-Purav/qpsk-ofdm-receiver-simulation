"""
Advanced QPSK Communication System Simulator - Complete GUI
"""
import sys
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QSpinBox, 
                             QDoubleSpinBox, QTabWidget, QGroupBox, QTextEdit,
                             QComboBox, QProgressBar)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from qpsk_modem import QPSKModem
from channel_models import AdvancedChannel
from synchronization import Synchronizer
from equalization import Equalizer
from channel_estimation import ChannelEstimator
from ofdm_engine import OFDMSystem, LTEFrame
from analysis import PerformanceAnalyzer

class AdvancedQPSKSimulator(QMainWindow):
    """Main application window with all features"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Advanced QPSK/OFDM Communication System")
        self.setGeometry(50, 50, 1600, 1000)
        
        # Initialize components
        self.modem = QPSKModem(sps=4, filter_span=8, beta=0.35)
        self.analyzer = PerformanceAnalyzer(self.modem)
        self.ofdm = OFDMSystem(n_subcarriers=64, cp_length=16)
        
        # Storage for simulation results
        self.last_tx_signal = None
        self.last_rx_signal = None
        self.last_channel = None
        self.last_equalized = None
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup user interface"""
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        
        # Title
        title = QLabel("Advanced QPSK/OFDM Communication System Simulator")
        title.setStyleSheet("font-size: 24px; font-weight: bold; padding: 10px; background-color: #2c3e50; color: white;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Controls
        controls = self.create_controls()
        layout.addWidget(controls)
        
        # Progress bar
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        
        # Tabs
        tabs = QTabWidget()
        
        # Tab 1: Constellation
        self.constellation_canvas = FigureCanvas(Figure(figsize=(8, 8)))
        tabs.addTab(self.constellation_canvas, "📊 Constellation")
        
        # Tab 2: Eye Diagram
        self.eye_canvas = FigureCanvas(Figure(figsize=(10, 8)))
        tabs.addTab(self.eye_canvas, "👁️ Eye Diagram")
        
        # Tab 3: BER
        self.ber_canvas = FigureCanvas(Figure(figsize=(10, 6)))
        tabs.addTab(self.ber_canvas, "📈 BER Performance")
        
        # Tab 4: Spectrum
        self.spectrum_canvas = FigureCanvas(Figure(figsize=(10, 6)))
        tabs.addTab(self.spectrum_canvas, "🌊 Spectrum")
        
        # Tab 5: Multipath Channel
        self.channel_canvas = FigureCanvas(Figure(figsize=(10, 8)))
        tabs.addTab(self.channel_canvas, "🛰️ Multipath Channel")
        
        # Tab 6: Equalization
        self.eq_canvas = FigureCanvas(Figure(figsize=(10, 8)))
        tabs.addTab(self.eq_canvas, "⚖️ Equalization")
        
        # Tab 7: Synchronization
        self.sync_canvas = FigureCanvas(Figure(figsize=(10, 8)))
        tabs.addTab(self.sync_canvas, "🔄 Synchronization")
        
        # Tab 8: OFDM
        self.ofdm_canvas = FigureCanvas(Figure(figsize=(10, 8)))
        tabs.addTab(self.ofdm_canvas, "📡 OFDM System")
        
        # Tab 9: Results
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setStyleSheet("font-family: 'Consolas', monospace; font-size: 11pt; background-color: #2b2b2b; color: #00ff00;")
        tabs.addTab(self.results_text, "📋 Results")
        
        layout.addWidget(tabs)
    
    def create_controls(self):
        """Create control panel"""
        group = QGroupBox("Simulation Parameters")
        group.setStyleSheet("QGroupBox { font-weight: bold; }")
        layout = QHBoxLayout()
        
        # Number of bits
        bits_layout = QVBoxLayout()
        bits_layout.addWidget(QLabel("Bits:"))
        self.num_bits_spin = QSpinBox()
        self.num_bits_spin.setRange(100, 100000)
        self.num_bits_spin.setValue(1000)
        self.num_bits_spin.setSingleStep(1000)
        bits_layout.addWidget(self.num_bits_spin)
        layout.addLayout(bits_layout)
        
        # SNR
        snr_layout = QVBoxLayout()
        snr_layout.addWidget(QLabel("SNR (dB):"))
        self.snr_spin = QDoubleSpinBox()
        self.snr_spin.setRange(-5, 30)
        self.snr_spin.setValue(15)
        self.snr_spin.setSingleStep(1)
        snr_layout.addWidget(self.snr_spin)
        layout.addLayout(snr_layout)
        
        # Channel model
        channel_layout = QVBoxLayout()
        channel_layout.addWidget(QLabel("Channel:"))
        self.channel_combo = QComboBox()
        self.channel_combo.addItems(['AWGN', 'LTE EPA', 'LTE ETU', 'LTE EVA', 'Rayleigh'])
        channel_layout.addWidget(self.channel_combo)
        layout.addLayout(channel_layout)
        
        # Equalizer
        eq_layout = QVBoxLayout()
        eq_layout.addWidget(QLabel("Equalizer:"))
        self.eq_combo = QComboBox()
        self.eq_combo.addItems(['None', 'Zero-Forcing', 'MMSE', 'LMS', 'DFE'])
        eq_layout.addWidget(self.eq_combo)
        layout.addLayout(eq_layout)
        
        # Buttons
        btn_layout = QVBoxLayout()
        
        run_btn = QPushButton("🚀 Run Full Simulation")
        run_btn.clicked.connect(self.run_full_simulation)
        run_btn.setStyleSheet("background-color: #27ae60; color: white; padding: 10px; font-size: 14px; font-weight: bold;")
        btn_layout.addWidget(run_btn)
        
        ofdm_btn = QPushButton("📡 OFDM Test")
        ofdm_btn.clicked.connect(self.run_ofdm_test)
        ofdm_btn.setStyleSheet("background-color: #2980b9; color: white; padding: 10px; font-size: 14px; font-weight: bold;")
        btn_layout.addWidget(ofdm_btn)
        
        ber_btn = QPushButton("📊 BER Analysis")
        ber_btn.clicked.connect(self.run_ber_analysis)
        ber_btn.setStyleSheet("background-color: #8e44ad; color: white; padding: 10px; font-size: 14px; font-weight: bold;")
        btn_layout.addWidget(ber_btn)
        
        layout.addLayout(btn_layout)
        
        group.setLayout(layout)
        return group
    
    def run_full_simulation(self):
        """Run complete simulation with all features"""
        num_bits = self.num_bits_spin.value()
        snr = self.snr_spin.value()
        channel_type = self.channel_combo.currentText()
        eq_type = self.eq_combo.currentText()
        
        self.progress.setVisible(True)
        self.progress.setValue(10)
        
        # Generate bits
        tx_bits = np.random.randint(0, 2, num_bits)
        
        # Modulate
        tx_signal, tx_symbols = self.modem.modulate(tx_bits)
        self.last_tx_signal = tx_signal
        self.progress.setValue(30)
        
        # Apply channel
        if channel_type == 'AWGN':
            rx_signal = AdvancedChannel.awgn(tx_signal, snr)
            channel_ir = np.array([1.0])
        elif 'LTE' in channel_type:
            model = channel_type.split()[-1]
            taps, delays = AdvancedChannel.lte_channel_model(model)
            fs = self.modem.sps
            channel_ir = AdvancedChannel.multipath_channel(taps, delays, fs)
            rx_signal = AdvancedChannel.apply_multipath(tx_signal, channel_ir)
            rx_signal = AdvancedChannel.awgn(rx_signal, snr)
        elif channel_type == 'Rayleigh':
            rx_signal, channel_matrix = AdvancedChannel.rayleigh_multipath(
                tx_signal, num_taps=4, max_delay_samples=8, 
                doppler_freq=100, fs=self.modem.sps
            )
            rx_signal = AdvancedChannel.awgn(rx_signal, snr)
            channel_ir = channel_matrix[:, 0]
        
        self.last_rx_signal = rx_signal
        self.last_channel = channel_ir
        self.progress.setValue(50)
        
        # Equalization
        if eq_type != 'None' and len(channel_ir) > 1:
            if eq_type == 'Zero-Forcing':
                rx_signal = Equalizer.zero_forcing(rx_signal, channel_ir)
            elif eq_type == 'MMSE':
                noise_var = 10**(-snr/10)
                rx_signal = Equalizer.mmse(rx_signal, channel_ir, noise_var)
            elif eq_type == 'LMS':
                # Use first 100 symbols as training
                training_syms = tx_symbols[:100]
                rx_signal, _ = Equalizer.lms_adaptive(rx_signal, training_syms, mu=0.01)
        
        self.last_equalized = rx_signal
        self.progress.setValue(70)
        
        # Carrier synchronization
        freq_offset = Synchronizer.carrier_frequency_offset_estimate(rx_signal[:1000])
        rx_signal = Synchronizer.correct_frequency_offset(rx_signal, freq_offset*self.modem.sps, self.modem.sps)
        
        # Demodulate
        rx_bits, rx_symbols = self.modem.demodulate(rx_signal)
        self.progress.setValue(90)
        
        # Calculate metrics
        min_len = min(len(tx_bits), len(rx_bits))
        errors = np.sum(tx_bits[:min_len] != rx_bits[:min_len])
        ber = errors / min_len
        
        # Update all plots
        self.plot_constellation(rx_symbols)
        self.plot_eye_diagram(rx_signal)
        self.plot_spectrum(tx_signal)
        self.plot_multipath_channel(channel_ir, rx_signal)
        self.plot_equalization(self.last_rx_signal, self.last_equalized)
        self.plot_synchronization(rx_signal)
        
        # Update results
        results = f"""
╔══════════════════════════════════════════════════════════╗
║        ADVANCED QPSK SIMULATION RESULTS                  ║
╚══════════════════════════════════════════════════════════╝

📊 PARAMETERS:
   • Bits transmitted: {num_bits}
   • SNR: {snr} dB
   • Channel: {channel_type}
   • Equalizer: {eq_type}
   • Samples/symbol: {self.modem.sps}
   • Filter span: {self.modem.filter_span}

📈 PERFORMANCE:
   • Bit errors: {errors}
   • BER: {ber:.6e}
   • Theoretical BER (AWGN): {self.analyzer.theoretical_ber_qpsk(snr):.6e}

🛰️ CHANNEL:
   • Type: {channel_type}
   • Taps: {len(channel_ir)}
   • Max delay: {len(channel_ir)-1} samples

🔄 SYNCHRONIZATION:
   • Freq offset estimate: {freq_offset:.6f} (normalized)

📡 SIGNAL:
   • TX length: {len(tx_signal)}
   • RX symbols: {len(rx_symbols)}
        
╔══════════════════════════════════════════════════════════╗
"""
        self.results_text.setText(results)
        
        self.progress.setValue(100)
        self.progress.setVisible(False)
        print(f"✓ Simulation complete: BER = {ber:.6e}")
    
    def run_ofdm_test(self):
        """Run OFDM-specific test"""
        num_bits = 1000
        snr = self.snr_spin.value()
        
        # Generate QPSK symbols
        tx_bits = np.random.randint(0, 2, num_bits)
        _, qpsk_symbols = self.modem.modulate(tx_bits)
        
        # OFDM modulation
        ofdm_signal, tx_pilots = self.ofdm.ofdm_modulate(qpsk_symbols[:self.ofdm.N])
        
        # Channel
        channel_type = self.channel_combo.currentText()
        if 'LTE' in channel_type:
            model = channel_type.split()[-1]
            taps, delays = AdvancedChannel.lte_channel_model(model)
            channel_ir = AdvancedChannel.multipath_channel(taps, delays, 1.0)
            rx_ofdm = AdvancedChannel.apply_multipath(ofdm_signal, channel_ir)
        else:
            rx_ofdm = ofdm_signal
        
        rx_ofdm = AdvancedChannel.awgn(rx_ofdm, snr)
        
        # OFDM demodulation
        rx_data, rx_pilots = self.ofdm.ofdm_demodulate(rx_ofdm)
        
        # Channel estimation
        H_est = self.ofdm.estimate_channel_ofdm(rx_pilots)
        
        # Equalization
        H_data = H_est[self.ofdm.data_indices]
        equalized_data = self.ofdm.equalize_ofdm(rx_data, H_data)
        
        # Plot OFDM-specific results
        self.plot_ofdm_results(H_est, rx_pilots, equalized_data)
        
        print("✓ OFDM test complete")
    
    def run_ber_analysis(self):
        """Run BER vs SNR analysis"""
        snr_range = np.arange(0, 16, 2)
        channel_type = self.channel_combo.currentText()
        
        self.progress.setVisible(True)
        print("Running BER analysis...")
        
        ber_sim = []
        for i, snr in enumerate(snr_range):
            self.progress.setValue(int((i+1)/len(snr_range) * 100))
            
            num_bits = 10000
            tx_bits = np.random.randint(0, 2, num_bits)
            tx_signal, _ = self.modem.modulate(tx_bits)
            
            # Apply channel
            if channel_type == 'AWGN':
                rx_signal = AdvancedChannel.awgn(tx_signal, snr)
            else:
                taps, delays = AdvancedChannel.lte_channel_model('EPA')
                channel_ir = AdvancedChannel.multipath_channel(taps, delays, self.modem.sps)
                rx_signal = AdvancedChannel.apply_multipath(tx_signal, channel_ir)
                rx_signal = AdvancedChannel.awgn(rx_signal, snr)
            
            rx_bits, _ = self.modem.demodulate(rx_signal)
            
            min_len = min(len(tx_bits), len(rx_bits))
            errors = np.sum(tx_bits[:min_len] != rx_bits[:min_len])
            ber = errors / min_len
            ber_sim.append(ber)
            
            print(f"  SNR = {snr:2d} dB: BER = {ber:.6e}")
        
        ber_theory = self.analyzer.theoretical_ber_qpsk(snr_range)
        self.plot_ber_curve(snr_range, np.array(ber_sim), ber_theory)
        
        self.progress.setVisible(False)
        print("✓ BER analysis complete")
    
    # ============ PLOTTING FUNCTIONS ============
    
    def plot_constellation(self, symbols):
        """Plot constellation diagram"""
        fig = self.constellation_canvas.figure
        fig.clear()
        ax = fig.add_subplot(111)
        
        ax.scatter(np.real(symbols), np.imag(symbols), alpha=0.5, s=20, c='cyan', edgecolors='blue')
        ax.grid(True, alpha=0.3, linestyle='--')
        ax.axhline(y=0, color='k', linewidth=1)
        ax.axvline(x=0, color='k', linewidth=1)
        ax.set_xlabel('In-Phase', fontsize=12)
        ax.set_ylabel('Quadrature', fontsize=12)
        ax.set_title('QPSK Constellation Diagram', fontsize=14, fontweight='bold')
        ax.axis('equal')
        
        # Ideal points
        ideal = np.array([-1-1j, -1+1j, 1+1j, 1-1j]) / np.sqrt(2)
        ax.scatter(np.real(ideal), np.imag(ideal), 
                  c='red', s=300, marker='x', linewidths=4, label='Ideal', zorder=10)
        ax.legend(fontsize=11)
        
        fig.tight_layout()
        self.constellation_canvas.draw()
    
    def plot_eye_diagram(self, signal):
        """Plot eye diagram"""
        fig = self.eye_canvas.figure
        fig.clear()
        
        sps = self.modem.sps
        ax1 = fig.add_subplot(211)
        ax2 = fig.add_subplot(212)
        
        # I component
        signal_i = np.real(signal)
        for i in range(0, min(len(signal_i) - 2*sps, 500*sps), sps):
            ax1.plot(signal_i[i:i+2*sps], 'b', alpha=0.05, linewidth=0.5)
        ax1.grid(True, alpha=0.3)
        ax1.set_title('Eye Diagram - In-Phase', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Amplitude')
        
        # Q component
        signal_q = np.imag(signal)
        for i in range(0, min(len(signal_q) - 2*sps, 500*sps), sps):
            ax2.plot(signal_q[i:i+2*sps], 'r', alpha=0.05, linewidth=0.5)
        ax2.grid(True, alpha=0.3)
        ax2.set_title('Eye Diagram - Quadrature', fontsize=12, fontweight='bold')
        ax2.set_xlabel('Samples')
        ax2.set_ylabel('Amplitude')
        
        fig.tight_layout()
        self.eye_canvas.draw()
    
    def plot_ber_curve(self, snr_db, ber_sim, ber_theory):
        """Plot BER curve"""
        fig = self.ber_canvas.figure
        fig.clear()
        ax = fig.add_subplot(111)
        
        ax.semilogy(snr_db, ber_sim, 'bo-', label='Simulation', 
                   linewidth=2, markersize=10)
        ax.semilogy(snr_db, ber_theory, 'r--', label='Theory (AWGN)', linewidth=2)
        
        ax.grid(True, which='both', alpha=0.3)
        ax.set_xlabel('Eb/N0 (dB)', fontsize=12)
        ax.set_ylabel('Bit Error Rate', fontsize=12)
        ax.set_title('BER Performance', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.set_ylim([1e-6, 1])
        
        fig.tight_layout()
        self.ber_canvas.draw()
    
    def plot_spectrum(self, signal):
        """Plot spectrum"""
        fig = self.spectrum_canvas.figure
        fig.clear()
        ax = fig.add_subplot(111)
        
        fs = self.modem.sps
        N = min(len(signal), 2048)
        signal_windowed = signal[:N] * np.hanning(N)
        
        fft_vals = np.fft.fftshift(np.fft.fft(signal_windowed))
        freqs = np.fft.fftshift(np.fft.fftfreq(N, 1/fs))
        psd = 10*np.log10(np.abs(fft_vals)**2 / N + 1e-12)
        
        ax.plot(freqs, psd, linewidth=1.5, color='blue')
        ax.grid(True, alpha=0.3)
        ax.set_xlabel('Normalized Frequency', fontsize=12)
        ax.set_ylabel('PSD (dB)', fontsize=12)
        ax.set_title('Power Spectral Density', fontsize=14, fontweight='bold')
        
        fig.tight_layout()
        self.spectrum_canvas.draw()
    
    def plot_multipath_channel(self, channel_ir, rx_signal):
        """Plot multipath channel characteristics"""
        fig = self.channel_canvas.figure
        fig.clear()
        
        ax1 = fig.add_subplot(221)
        ax2 = fig.add_subplot(222)
        ax3 = fig.add_subplot(212)
        
        # Channel impulse response
        ax1.stem(np.abs(channel_ir), basefmt=' ')
        ax1.set_title('Channel Impulse Response (Magnitude)', fontweight='bold')
        ax1.set_xlabel('Tap Index')
        ax1.set_ylabel('|h|')
        ax1.grid(True, alpha=0.3)
        
        # Channel frequency response
        H = np.fft.fft(channel_ir, 512)
        freqs = np.fft.fftfreq(512)
        ax2.plot(np.fft.fftshift(freqs), 20*np.log10(np.abs(np.fft.fftshift(H)) + 1e-12))
        ax2.set_title('Channel Frequency Response', fontweight='bold')
        ax2.set_xlabel('Normalized Frequency')
        ax2.set_ylabel('|H(f)| (dB)')
        ax2.grid(True, alpha=0.3)
        
        # Power delay profile
        power_profile = 10*np.log10(np.abs(channel_ir)**2 + 1e-12)
        ax3.stem(power_profile, basefmt=' ')
        ax3.set_title('Power Delay Profile', fontweight='bold')
        ax3.set_xlabel('Delay (samples)')
        ax3.set_ylabel('Power (dB)')
        ax3.grid(True, alpha=0.3)
        
        fig.tight_layout()
        self.channel_canvas.draw()
    
    def plot_equalization(self, before_eq, after_eq):
        """Plot equalization results"""
        if before_eq is None or after_eq is None:
            return
        
        fig = self.eq_canvas.figure
        fig.clear()
        
        ax1 = fig.add_subplot(221)
        ax2 = fig.add_subplot(222)
        ax3 = fig.add_subplot(212)
        
        # Before equalization
        ax1.scatter(np.real(before_eq[:1000]), np.imag(before_eq[:1000]), 
                   alpha=0.5, s=10, c='red')
        ax1.set_title('Before Equalization', fontweight='bold')
        ax1.set_xlabel('I')
        ax1.set_ylabel('Q')
        ax1.grid(True, alpha=0.3)
        ax1.axis('equal')
        
        # After equalization
        ax2.scatter(np.real(after_eq[:1000]), np.imag(after_eq[:1000]), 
                   alpha=0.5, s=10, c='green')
        ax2.set_title('After Equalization', fontweight='bold')
        ax2.set_xlabel('I')
        ax2.set_ylabel('Q')
        ax2.grid(True, alpha=0.3)
        ax2.axis('equal')
        
        # Comparison
        ax3.plot(np.abs(before_eq[:500]), 'r-', alpha=0.7, label='Before', linewidth=1)
        ax3.plot(np.abs(after_eq[:500]), 'g-', alpha=0.7, label='After', linewidth=1)
        ax3.set_title('Signal Magnitude Comparison', fontweight='bold')
        ax3.set_xlabel('Sample Index')
        ax3.set_ylabel('Magnitude')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        fig.tight_layout()
        self.eq_canvas.draw()
    
    def plot_synchronization(self, signal):
        """Plot synchronization results"""
        fig = self.sync_canvas.figure
        fig.clear()
        
        ax1 = fig.add_subplot(311)
        ax2 = fig.add_subplot(312)
        ax3 = fig.add_subplot(313)
        
        # Frequency offset estimate
        freq_offset = Synchronizer.carrier_frequency_offset_estimate(signal[:2000])
        ax1.text(0.5, 0.5, f'Frequency Offset Estimate:\n{freq_offset:.6f} (normalized)', 
                ha='center', va='center', fontsize=16, transform=ax1.transAxes,
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        ax1.axis('off')
        ax1.set_title('Carrier Frequency Offset', fontweight='bold')
        
        # Phase tracking (Costas loop)
        if len(signal) > 1000:
            corrected, phase_error = Synchronizer.costas_loop(signal[:1000])
            ax2.plot(phase_error, linewidth=1)
            ax2.set_title('Costas Loop Phase Error', fontweight='bold')
            ax2.set_xlabel('Sample')
            ax2.set_ylabel('Phase Error')
            ax2.grid(True, alpha=0.3)
        
        # Timing recovery
        if len(signal) > self.modem.sps * 100:
            timing_err, _ = Synchronizer.mueller_muller_timing(signal[:self.modem.sps*100], self.modem.sps)
            ax3.plot(timing_err, linewidth=1, color='purple')
            ax3.set_title('Mueller & Müller Timing Error', fontweight='bold')
            ax3.set_xlabel('Symbol Index')
            ax3.set_ylabel('Timing Error')
            ax3.grid(True, alpha=0.3)
        
        fig.tight_layout()
        self.sync_canvas.draw()
    
    def plot_ofdm_results(self, H_est, rx_pilots, equalized_data):
        """Plot OFDM-specific results"""
        fig = self.ofdm_canvas.figure
        fig.clear()
        
        ax1 = fig.add_subplot(221)
        ax2 = fig.add_subplot(222)
        ax3 = fig.add_subplot(212)
        
        # Channel estimate magnitude
        ax1.plot(np.abs(H_est), linewidth=2, color='blue')
        ax1.set_title('Channel Estimate |H(f)|', fontweight='bold')
        ax1.set_xlabel('Subcarrier Index')
        ax1.set_ylabel('Magnitude')
        ax1.grid(True, alpha=0.3)
        
        # Channel estimate phase
        ax2.plot(np.angle(H_est), linewidth=2, color='red')
        ax2.set_title('Channel Estimate ∠H(f)', fontweight='bold')
        ax2.set_xlabel('Subcarrier Index')
        ax2.set_ylabel('Phase (rad)')
        ax2.grid(True, alpha=0.3)
        
        # Equalized constellation
        ax3.scatter(np.real(equalized_data), np.imag(equalized_data), 
                   alpha=0.6, s=30, c='green', edgecolors='darkgreen')
        ideal = np.array([-1-1j, -1+1j, 1+1j, 1-1j]) / np.sqrt(2)
        ax3.scatter(np.real(ideal), np.imag(ideal), 
                   c='red', s=300, marker='x', linewidths=4, label='Ideal')
        ax3.set_title('OFDM Equalized Data Constellation', fontweight='bold')
        ax3.set_xlabel('I')
        ax3.set_ylabel('Q')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        ax3.axis('equal')
        
        fig.tight_layout()
        self.ofdm_canvas.draw()


def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Dark theme (optional but looks professional)
    app.setStyleSheet("""
        QMainWindow {
            background-color: #1e1e1e;
        }
        QWidget {
            background-color: #2d2d30;
            color: #ffffff;
        }
        QGroupBox {
            border: 2px solid #3f3f46;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QLabel {
            color: #ffffff;
        }
        QPushButton {
            border-radius: 5px;
            padding: 8px;
        }
        QPushButton:hover {
            background-color: #3e8e41;
        }
    """)
    
    window = AdvancedQPSKSimulator()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()