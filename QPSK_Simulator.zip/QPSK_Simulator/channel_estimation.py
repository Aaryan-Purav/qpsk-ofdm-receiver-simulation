"""
Channel Estimation Techniques
"""
import numpy as np

class ChannelEstimator:
    """Channel estimation algorithms"""
    
    @staticmethod
    def least_squares(rx_pilots, tx_pilots):
        """
        Least Squares (LS) channel estimation
        
        Args:
            rx_pilots: Received pilot symbols
            tx_pilots: Transmitted pilot symbols (known)
        
        Returns:
            Channel estimate
        """
        # H = Y / X
        H_est = rx_pilots / tx_pilots
        
        return H_est
    
    @staticmethod
    def mmse_estimation(rx_pilots, tx_pilots, snr_linear, 
                       channel_autocorr=None):
        """
        MMSE Channel Estimation
        
        Args:
            rx_pilots: Received pilots
            tx_pilots: Transmitted pilots
            snr_linear: SNR in linear scale
            channel_autocorr: Channel autocorrelation (if known)
        
        Returns:
            Channel estimate
        """
        # Simple MMSE (assuming diagonal channel correlation)
        if channel_autocorr is None:
            channel_autocorr = 1.0
        
        H_ls = rx_pilots / tx_pilots
        
        # MMSE combining
        mmse_factor = channel_autocorr * snr_linear / (channel_autocorr * snr_linear + 1)
        H_mmse = mmse_factor * H_ls
        
        return H_mmse
    
    @staticmethod
    def interpolate_channel(pilot_estimates, pilot_positions, data_positions):
        """
        Interpolate channel from pilot estimates
        
        Args:
            pilot_estimates: Channel estimates at pilot locations
            pilot_positions: Indices of pilot positions
            data_positions: Indices where channel is needed
        
        Returns:
            Interpolated channel estimates
        """
        # Linear interpolation
        H_interp = np.interp(data_positions, pilot_positions, pilot_estimates)
        
        return H_interp
    
    @staticmethod
    def pilot_based_estimation(rx_signal, tx_pilots, pilot_spacing, 
                               total_subcarriers):
        """
        Complete pilot-based channel estimation for OFDM
        
        Args:
            rx_signal: Received OFDM symbols
            tx_pilots: Known pilot symbols
            pilot_spacing: Spacing between pilots
            total_subcarriers: Total number of subcarriers
        
        Returns:
            Full channel estimate across all subcarriers
        """
        # Extract pilot positions
        pilot_positions = np.arange(0, total_subcarriers, pilot_spacing)
        
        # LS estimation at pilots
        rx_pilots = rx_signal[pilot_positions]
        H_pilots = ChannelEstimator.least_squares(rx_pilots, tx_pilots)
        
        # Interpolate to all subcarriers
        all_positions = np.arange(total_subcarriers)
        H_full = ChannelEstimator.interpolate_channel(
            H_pilots, pilot_positions, all_positions
        )
        
        return H_full