"""
QPSK Modulator and Demodulator
"""
import numpy as np
from filters import PulseShaper

class QPSKModem:
    """Complete QPSK Modulation and Demodulation"""
    
    def __init__(self, sps=4, filter_span=8, beta=0.35):
        """
        Initialize QPSK Modem
        
        Args:
            sps: Samples per symbol
            filter_span: Filter span in symbols
            beta: Roll-off factor
        """
        self.sps = sps
        self.filter_span = filter_span
        self.beta = beta
        
        # Generate pulse shaping filter
        self.tx_filter = PulseShaper.root_raised_cosine(sps, filter_span, beta)
        self.rx_filter = self.tx_filter  # Matched filter
        
    def bits_to_symbols(self, bits):
        """
        Map bits to QPSK symbols (Gray coding)
        
        Gray coding mapping:
        00 -> -1-1j (π + π/4)
        01 -> -1+1j (π - π/4)  
        11 -> +1+1j (π/4)
        10 -> +1-1j (-π/4)
        """
        if len(bits) % 2 != 0:
            bits = np.append(bits, 0)  # Pad if odd
        
        # Reshape to pairs
        bit_pairs = bits.reshape(-1, 2)
        
        # Gray coded QPSK mapping
        symbols = np.zeros(len(bit_pairs), dtype=complex)
        
        for i, (b1, b2) in enumerate(bit_pairs):
            if b1 == 0 and b2 == 0:
                symbols[i] = -1 - 1j  # 00
            elif b1 == 0 and b2 == 1:
                symbols[i] = -1 + 1j  # 01
            elif b1 == 1 and b2 == 1:
                symbols[i] = +1 + 1j  # 11
            else:  # b1 == 1 and b2 == 0
                symbols[i] = +1 - 1j  # 10
        
        # Normalize power
        symbols = symbols / np.sqrt(2)
        
        return symbols
    
    def symbols_to_bits(self, symbols):
        """
        Demodulate QPSK symbols to bits (Gray decoding)
        """
        bits = np.zeros(len(symbols) * 2, dtype=int)
        
        for i, sym in enumerate(symbols):
            # Decision regions
            if np.real(sym) >= 0 and np.imag(sym) >= 0:
                bits[2*i:2*i+2] = [1, 1]  # 11
            elif np.real(sym) < 0 and np.imag(sym) >= 0:
                bits[2*i:2*i+2] = [0, 1]  # 01
            elif np.real(sym) < 0 and np.imag(sym) < 0:
                bits[2*i:2*i+2] = [0, 0]  # 00
            else:  # real >= 0 and imag < 0
                bits[2*i:2*i+2] = [1, 0]  # 10
        
        return bits
    
    def modulate(self, bits):
        """
        Complete QPSK modulation with pulse shaping
        
        Args:
            bits: Binary data
        
        Returns:
            Modulated signal
        """
        # Bits to symbols
        symbols = self.bits_to_symbols(bits)
        
        # Upsample
        upsampled = np.zeros(len(symbols) * self.sps, dtype=complex)
        upsampled[::self.sps] = symbols
        
        # Pulse shaping filter
        tx_signal = np.convolve(upsampled, self.tx_filter, mode='same')
        
        return tx_signal, symbols
    
    def demodulate(self, rx_signal):
        """
        Complete QPSK demodulation
        
        Args:
            rx_signal: Received signal
        
        Returns:
            Demodulated bits
        """
        # Matched filtering
        filtered = np.convolve(rx_signal, self.rx_filter, mode='same')
        
        # Timing recovery (simple: sample at known points)
        delay = self.filter_span * self.sps // 2
        sampled = filtered[delay::self.sps]
        
        # Symbol detection
        bits = self.symbols_to_bits(sampled)
        
        return bits, sampled