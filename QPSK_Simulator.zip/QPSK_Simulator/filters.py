"""
Pulse Shaping Filters for QPSK Communication System
"""
import numpy as np
from scipy import signal

class PulseShaper:
    """Root Raised Cosine and other pulse shaping filters"""
    
    @staticmethod
    def root_raised_cosine(sps, span, beta):
        """
        Generate Root Raised Cosine filter
        
        Args:
            sps: Samples per symbol
            span: Filter span in symbols
            beta: Roll-off factor (0 to 1)
        
        Returns:
            RRC filter coefficients
        """
        n = np.arange(-span*sps//2, span*sps//2 + 1)
        t = n / sps
        
        # Avoid division by zero
        rrc = np.zeros(len(t))
        
        for i, ti in enumerate(t):
            if ti == 0:
                rrc[i] = (1 + beta*(4/np.pi - 1))
            elif abs(ti) == 1/(4*beta) and beta != 0:
                rrc[i] = (beta/np.sqrt(2)) * ((1 + 2/np.pi)*np.sin(np.pi/(4*beta)) + 
                                               (1 - 2/np.pi)*np.cos(np.pi/(4*beta)))
            else:
                num = np.sin(np.pi*ti*(1-beta)) + 4*beta*ti*np.cos(np.pi*ti*(1+beta))
                den = np.pi*ti*(1 - (4*beta*ti)**2)
                rrc[i] = num / den
        
        # Normalize
        rrc = rrc / np.sqrt(np.sum(rrc**2))
        return rrc
    
    @staticmethod
    def raised_cosine(sps, span, beta):
        """Generate Raised Cosine filter"""
        n = np.arange(-span*sps//2, span*sps//2 + 1)
        t = n / sps
        
        rc = np.zeros(len(t))
        
        for i, ti in enumerate(t):
            if ti == 0:
                rc[i] = 1
            elif abs(ti) == 1/(2*beta) and beta != 0:
                rc[i] = (np.pi/4) * np.sinc(1/(2*beta))
            else:
                rc[i] = np.sinc(ti) * np.cos(np.pi*beta*ti) / (1 - (2*beta*ti)**2)
        
        rc = rc / np.sqrt(np.sum(rc**2))
        return rc
    