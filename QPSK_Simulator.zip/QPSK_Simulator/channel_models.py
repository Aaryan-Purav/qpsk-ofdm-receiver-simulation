"""
Advanced Channel Models with Multipath and ISI
"""
import numpy as np
from scipy import signal

class AdvancedChannel:
    """Realistic wireless channel models"""
    
    @staticmethod
    def multipath_channel(taps, delays, fs):
        """
        Create multipath channel impulse response
        
        Args:
            taps: Complex tap gains [h0, h1, h2, ...]
            delays: Delay of each tap in seconds
            fs: Sampling frequency
        
        Returns:
            Channel impulse response (sampled)
        """
        max_delay_samples = int(np.max(delays) * fs) + 1
        h = np.zeros(max_delay_samples, dtype=complex)
        
        for tap, delay in zip(taps, delays):
            delay_samples = int(delay * fs)
            if delay_samples < len(h):
                h[delay_samples] = tap
        
        # Normalize power
        h = h / np.sqrt(np.sum(np.abs(h)**2))
        
        return h
    
    @staticmethod
    def apply_multipath(signal, channel_ir):
        """
        Apply multipath channel (introduces ISI)
        
        Args:
            signal: Input signal
            channel_ir: Channel impulse response
        
        Returns:
            Signal after multipath propagation
        """
        # Convolve signal with channel
        output = np.convolve(signal, channel_ir, mode='same')
        return output
    
    @staticmethod
    def rayleigh_multipath(signal, num_taps, max_delay_samples, doppler_freq, fs):
        """
        Time-varying Rayleigh multipath channel
        
        Args:
            signal: Input signal
            num_taps: Number of multipath taps
            max_delay_samples: Maximum delay spread in samples
            doppler_freq: Maximum Doppler frequency
            fs: Sampling frequency
        
        Returns:
            Faded signal, channel coefficients (time-varying)
        """
        n_samples = len(signal)
        output = np.zeros(n_samples, dtype=complex)
        h_matrix = np.zeros((num_taps, n_samples), dtype=complex)
        
        # Generate time-varying tap gains using Jakes model
        for tap in range(num_taps):
            h_matrix[tap, :] = AdvancedChannel._jakes_fading(
                n_samples, doppler_freq, fs
            )
        
        # Apply multipath with varying taps
        for i in range(n_samples):
            for tap in range(num_taps):
                delay = tap * (max_delay_samples // num_taps)
                if i >= delay:
                    output[i] += h_matrix[tap, i] * signal[i - delay]
        
        # Normalize
        power = np.sqrt(np.mean(np.abs(h_matrix)**2))
        output = output / power
        h_matrix = h_matrix / power
        
        return output, h_matrix
    
    @staticmethod
    def _jakes_fading(n_samples, fd, fs):
        """
        Generate Rayleigh fading using Jakes model
        
        Args:
            n_samples: Number of samples
            fd: Doppler frequency
            fs: Sampling frequency
        
        Returns:
            Complex fading coefficients
        """
        n_oscillators = 20
        t = np.arange(n_samples) / fs
        
        phases = np.random.uniform(0, 2*np.pi, n_oscillators)
        angles = np.pi * (np.arange(n_oscillators) - 0.5) / n_oscillators
        
        h = np.zeros(n_samples, dtype=complex)
        for i in range(n_oscillators):
            h += np.exp(1j * (2*np.pi*fd*t*np.cos(angles[i]) + phases[i]))
        
        h = h / np.sqrt(n_oscillators)
        return h
    
    @staticmethod
    def lte_channel_model(model_type='EPA'):
        """
        3GPP LTE channel models
        
        Args:
            model_type: 'EPA' (Extended Pedestrian A)
                       'ETU' (Extended Typical Urban)
                       'EVA' (Extended Vehicular A)
        
        Returns:
            taps, delays (in seconds)
        """
        if model_type == 'EPA':
            # Extended Pedestrian A (low delay spread)
            delays = np.array([0, 30, 70, 90, 110, 190, 410]) * 1e-9
            power_db = np.array([0.0, -1.0, -2.0, -3.0, -8.0, -17.2, -20.8])
        elif model_type == 'ETU':
            # Extended Typical Urban (medium delay spread)
            delays = np.array([0, 50, 120, 200, 230, 500, 1600, 2300, 5000]) * 1e-9
            power_db = np.array([-1.0, -1.0, -1.0, 0.0, 0.0, 0.0, -3.0, -5.0, -7.0])
        elif model_type == 'EVA':
            # Extended Vehicular A (high delay spread)
            delays = np.array([0, 30, 150, 310, 370, 710, 1090, 1730, 2510]) * 1e-9
            power_db = np.array([0.0, -1.5, -1.4, -3.6, -0.6, -9.1, -7.0, -12.0, -16.9])
        else:
            raise ValueError(f"Unknown model: {model_type}")
        
        # Convert power from dB to linear
        power_linear = 10**(power_db / 10)
        taps = np.sqrt(power_linear) * (np.random.randn(len(power_linear)) + 
                                         1j*np.random.randn(len(power_linear))) / np.sqrt(2)
        
        return taps, delays
    
    @staticmethod
    def awgn(signal, snr_db):
        """AWGN channel (from before, kept for compatibility)"""
        signal_power = np.mean(np.abs(signal)**2)
        snr_linear = 10**(snr_db / 10)
        noise_power = signal_power / snr_linear
        
        noise = np.sqrt(noise_power/2) * (np.random.randn(len(signal)) + 
                                          1j*np.random.randn(len(signal)))
        return signal + noise