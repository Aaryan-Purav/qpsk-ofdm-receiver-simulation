"""
Visualization Functions
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.figure import Figure

class Visualizer:
    """Create various plots for analysis"""
    
    @staticmethod
    def constellation_diagram(symbols, title="QPSK Constellation"):
        """Plot constellation diagram"""
        fig, ax = plt.subplots(figsize=(8, 8))
        
        ax.scatter(np.real(symbols), np.imag(symbols), alpha=0.5, s=20)
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linewidth=0.5)
        ax.axvline(x=0, color='k', linewidth=0.5)
        ax.set_xlabel('In-Phase')
        ax.set_ylabel('Quadrature')
        ax.set_title(title)
        ax.axis('equal')
        
        # Add ideal constellation points
        ideal = np.array([-1-1j, -1+1j, 1+1j, 1-1j]) / np.sqrt(2)
        ax.scatter(np.real(ideal), np.imag(ideal), 
                  c='red', s=200, marker='x', linewidths=3,
                  label='Ideal')
        ax.legend()
        
        return fig
    
    @staticmethod
    def eye_diagram(signal, sps, title="Eye Diagram"):
        """Plot eye diagram"""
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))
        
        # I component
        signal_i = np.real(signal)
        for i in range(0, len(signal_i) - 2*sps, sps):
            ax1.plot(signal_i[i:i+2*sps], 'b', alpha=0.1)
        ax1.grid(True, alpha=0.3)
        ax1.set_title(f'{title} - In-Phase')
        ax1.set_xlabel('Samples')
        ax1.set_ylabel('Amplitude')
        
        # Q component
        signal_q = np.imag(signal)
        for i in range(0, len(signal_q) - 2*sps, sps):
            ax2.plot(signal_q[i:i+2*sps], 'r', alpha=0.1)
        ax2.grid(True, alpha=0.3)
        ax2.set_title(f'{title} - Quadrature')
        ax2.set_xlabel('Samples')
        ax2.set_ylabel('Amplitude')
        
        plt.tight_layout()
        return fig
    
    @staticmethod
    def ber_curve(snr_db, ber_sim, ber_theory=None, title="BER Performance"):
        """Plot BER vs SNR curve"""
        fig, ax = plt.subplots(figsize=(10, 6))
        
        ax.semilogy(snr_db, ber_sim, 'bo-', label='Simulation', linewidth=2, markersize=8)
        
        if ber_theory is not None:
            ax.semilogy(snr_db, ber_theory, 'r--', label='Theory', linewidth=2)
        
        ax.grid(True, which='both', alpha=0.3)
        ax.set_xlabel('Eb/N0 (dB)', fontsize=12)
        ax.set_ylabel('Bit Error Rate', fontsize=12)
        ax.set_title(title, fontsize=14)
        ax.legend(fontsize=11)
        ax.set_ylim([1e-6, 1])
        
        return fig
    
    @staticmethod
    def spectrum(signal, fs, title="Power Spectral Density"):
        """Plot power spectral density"""
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Compute PSD
        f, psd = plt.psd(signal, NFFT=1024, Fs=fs, return_line=False)
        
        ax.plot(f, 10*np.log10(psd))
        ax.grid(True, alpha=0.3)
        ax.set_xlabel('Frequency (Hz)')
        ax.set_ylabel('Power/Frequency (dB/Hz)')
        ax.set_title(title)
        
        return fig