"""
Communication Channel Models
"""
import numpy as np

class Channel:
    """Various channel impairments"""
    
    @staticmethod
    def awgn(signal, snr_db):
        """
        Add Additive White Gaussian Noise
        
        Args:
            signal: Input signal
            snr_db: SNR in dB
        
        Returns:
            Noisy signal
        """
        # Calculate signal power
        signal_power = np.mean(np.abs(signal)**2)
        
        # Calculate noise power
        snr_linear = 10**(snr_db / 10)
        noise_power = signal_power / snr_linear
        
        # Generate complex noise
        noise = np.sqrt(noise_power/2) * (np.random.randn(len(signal)) + 
                                          1j*np.random.randn(len(signal)))
        
        return signal + noise
    
    @staticmethod
    def rayleigh_fading(signal, fd, fs, duration):
        """
        Rayleigh flat fading channel
        
        Args:
            signal: Input signal
            fd: Doppler frequency
            fs: Sampling frequency
            duration: Signal duration
        
        Returns:
            Faded signal
        """
        n_samples = len(signal)
        t = np.arange(n_samples) / fs
        
        # Jakes model for Rayleigh fading
        n_oscillators = 20
        phases = np.random.uniform(0, 2*np.pi, n_oscillators)
        angles = np.pi * (np.arange(n_oscillators) - 0.5) / n_oscillators
        
        h = np.zeros(n_samples, dtype=complex)
        for i in range(n_oscillators):
            h += np.exp(1j * (2*np.pi*fd*t*np.cos(angles[i]) + phases[i]))
        
        h = h / np.sqrt(n_oscillators)
        
        return signal * h
    
    @staticmethod
    def frequency_offset(signal, offset_hz, fs):
        """
        Add carrier frequency offset
        
        Args:
            signal: Input signal
            offset_hz: Frequency offset in Hz
            fs: Sampling frequency
        
        Returns:
            Signal with frequency offset
        """
        t = np.arange(len(signal)) / fs
        offset_signal = signal * np.exp(1j * 2*np.pi * offset_hz * t)
        
        return offset_signal
    
    @staticmethod
    def phase_noise(signal, phase_noise_std):
        """
        Add phase noise
        
        Args:
            signal: Input signal
            phase_noise_std: Standard deviation of phase noise (radians)
        
        Returns:
            Signal with phase noise
        """
        phase_noise = np.random.randn(len(signal)) * phase_noise_std
        cumulative_phase = np.cumsum(phase_noise)
        
        return signal * np.exp(1j * cumulative_phase)