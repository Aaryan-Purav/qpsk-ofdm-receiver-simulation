"""
Carrier and Timing Synchronization
"""
import numpy as np

class Synchronizer:
    """Synchronization algorithms for carrier and timing recovery"""
    
    @staticmethod
    def carrier_frequency_offset_estimate(signal, m=4):
        """
        Estimate carrier frequency offset using M-th power method
        
        Args:
            signal: Received signal
            m: Modulation order (4 for QPSK)
        
        Returns:
            Frequency offset estimate (normalized)
        """
        # Raise signal to M-th power to remove modulation
        signal_m = signal ** m
        
        # Compute phase difference
        phase = np.angle(np.sum(signal_m))
        
        # Frequency offset
        freq_offset = phase / (2 * np.pi * m)
        
        return freq_offset
    
    @staticmethod
    def correct_frequency_offset(signal, freq_offset, fs):
        """
        Correct carrier frequency offset
        
        Args:
            signal: Input signal
            freq_offset: Frequency offset in Hz
            fs: Sampling frequency
        
        Returns:
            Corrected signal
        """
        t = np.arange(len(signal)) / fs
        correction = np.exp(-1j * 2 * np.pi * freq_offset * t)
        
        return signal * correction
    
    @staticmethod
    def costas_loop(signal, loop_bw=0.01, damping=1/np.sqrt(2)):
        """
        Costas Loop for carrier phase synchronization (QPSK)
        
        Args:
            signal: Input signal
            loop_bw: Loop bandwidth
            damping: Damping factor
        
        Returns:
            Phase-corrected signal, phase error trajectory
        """
        n_samples = len(signal)
        output = np.zeros(n_samples, dtype=complex)
        phase_error = np.zeros(n_samples)
        
        # Loop filter parameters
        theta_i = 2 * damping * loop_bw
        theta_p = loop_bw ** 2
        
        phase = 0.0
        freq = 0.0
        
        for i in range(n_samples):
            # Rotate by estimated phase
            output[i] = signal[i] * np.exp(-1j * phase)
            
            # Phase detector (for QPSK)
            error = np.real(output[i]) * np.imag(output[i])
            phase_error[i] = error
            
            # Loop filter
            freq = freq + theta_p * error
            phase = phase + freq + theta_i * error
            
            # Wrap phase
            phase = np.mod(phase + np.pi, 2*np.pi) - np.pi
        
        return output, phase_error
    
    @staticmethod
    def mueller_muller_timing(signal, sps):
        """
        Mueller & Müller timing recovery
        
        Args:
            signal: Received signal (oversampled)
            sps: Samples per symbol
        
        Returns:
            Timing error estimates, recovered timing instants
        """
        n_samples = len(signal)
        n_symbols_est = n_samples // sps
        
        timing_error = []
        sample_points = []
        
        mu = 0.0  # Timing offset
        mu_step = 1.0 / sps
        loop_gain = 0.01
        
        i = 0
        prev_sample = 0
        prev_decision = 0
        
        while i < n_samples - sps:
            # Interpolate at current timing estimate
            frac_idx = i + mu
            idx_low = int(np.floor(frac_idx))
            idx_high = idx_low + 1
            
            if idx_high >= n_samples:
                break
            
            frac = frac_idx - idx_low
            current_sample = (1 - frac) * signal[idx_low] + frac * signal[idx_high]
            
            # Make decision
            current_decision = np.sign(np.real(current_sample))
            
            # Timing error detector (Mueller & Müller)
            error = np.real((current_sample - prev_sample) * np.conj(prev_decision))
            timing_error.append(error)
            
            # Update timing
            mu = mu + loop_gain * error
            
            # Advance by one symbol
            i += sps
            
            prev_sample = current_sample
            prev_decision = current_decision
            sample_points.append(frac_idx)
        
        return np.array(timing_error), np.array(sample_points)
    
    @staticmethod
    def gardner_timing_recovery(signal, sps, loop_bw=0.01):
        """
        Gardner timing error detector
        
        Args:
            signal: Received signal
            sps: Samples per symbol
            loop_bw: Loop bandwidth
        
        Returns:
            Resampled signal at symbol rate
        """
        mu = 0.0
        output_samples = []
        
        i = 0
        while i < len(signal) - 2*sps:
            # Interpolate at mu
            idx = int(i + mu)
            if idx + sps//2 + 1 >= len(signal):
                break
            
            # Get samples
            current = signal[idx]
            mid = signal[idx + sps//2]
            next_sample = signal[idx + sps]
            
            # Gardner TED
            error = np.real((current - next_sample) * np.conj(mid))
            
            # Update mu
            mu = mu + loop_bw * error
            mu = np.clip(mu, -sps/2, sps/2)
            
            output_samples.append(current)
            i += sps
        
        return np.array(output_samples)