"""
Adaptive Equalization Techniques
"""
import numpy as np

class Equalizer:
    """Various equalization algorithms"""
    
    @staticmethod
    def zero_forcing(rx_signal, channel_estimate):
        """
        Zero-Forcing Equalization
        
        Args:
            rx_signal: Received signal
            channel_estimate: Estimated channel frequency response
        
        Returns:
            Equalized signal
        """
        # Frequency domain equalization
        RX = np.fft.fft(rx_signal)
        H = np.fft.fft(channel_estimate, len(rx_signal))
        
        # Avoid division by zero
        H_safe = np.where(np.abs(H) < 1e-10, 1e-10, H)
        
        # ZF equalization
        Y = RX / H_safe
        
        equalized = np.fft.ifft(Y)
        return equalized
    
    @staticmethod
    def mmse(rx_signal, channel_estimate, noise_variance=0.01):
        """
        Minimum Mean Square Error (MMSE) Equalization
        
        Args:
            rx_signal: Received signal
            channel_estimate: Estimated channel
            noise_variance: Noise variance estimate
        
        Returns:
            Equalized signal
        """
        RX = np.fft.fft(rx_signal)
        H = np.fft.fft(channel_estimate, len(rx_signal))
        
        # MMSE equalization: W = H* / (|H|^2 + sigma^2)
        W = np.conj(H) / (np.abs(H)**2 + noise_variance)
        
        Y = RX * W
        equalized = np.fft.ifft(Y)
        
        return equalized
    
    @staticmethod
    def lms_adaptive(rx_signal, training_symbols, mu=0.01, filter_length=15):
        """
        Least Mean Squares (LMS) Adaptive Equalizer
        
        Args:
            rx_signal: Received signal
            training_symbols: Known training sequence
            mu: Step size (learning rate)
            filter_length: Equalizer filter length
        
        Returns:
            Equalized signal, filter coefficients
        """
        n_train = len(training_symbols)
        n_total = len(rx_signal)
        
        # Initialize filter
        w = np.zeros(filter_length, dtype=complex)
        w[filter_length//2] = 1.0  # Start with delta function
        
        # Training phase
        for i in range(filter_length, n_train):
            # Input vector
            x = rx_signal[i-filter_length+1:i+1][::-1]
            
            # Filter output
            y = np.dot(w, x)
            
            # Error
            e = training_symbols[i] - y
            
            # Update weights
            w = w + mu * np.conj(e) * x
        
        # Equalize entire signal
        equalized = np.zeros(n_total - filter_length + 1, dtype=complex)
        for i in range(filter_length-1, n_total):
            x = rx_signal[i-filter_length+1:i+1][::-1]
            equalized[i-filter_length+1] = np.dot(w, x)
        
        return equalized, w
    
    @staticmethod
    def decision_feedback_equalizer(rx_signal, training_symbols, 
                                    ff_length=10, fb_length=5, mu=0.01):
        """
        Decision Feedback Equalizer (DFE)
        
        Args:
            rx_signal: Received signal
            training_symbols: Training sequence
            ff_length: Feedforward filter length
            fb_length: Feedback filter length
            mu: Step size
        
        Returns:
            Equalized signal
        """
        n_train = len(training_symbols)
        n_total = len(rx_signal)
        
        # Initialize filters
        w_ff = np.zeros(ff_length, dtype=complex)
        w_fb = np.zeros(fb_length, dtype=complex)
        w_ff[ff_length//2] = 1.0
        
        # Decision buffer
        decisions = np.zeros(fb_length, dtype=complex)
        
        equalized = np.zeros(n_total, dtype=complex)
        
        # Training phase
        for i in range(ff_length, n_train):
            # Feedforward
            x_ff = rx_signal[i-ff_length+1:i+1][::-1]
            y_ff = np.dot(w_ff, x_ff)
            
            # Feedback
            y_fb = np.dot(w_fb, decisions)
            
            # Output
            y = y_ff - y_fb
            equalized[i] = y
            
            # Error (using training symbols)
            e = training_symbols[i] - y
            
            # Update filters
            w_ff = w_ff + mu * np.conj(e) * x_ff
            w_fb = w_fb + mu * np.conj(e) * decisions
            
            # Update decision buffer
            decisions = np.roll(decisions, 1)
            decisions[0] = training_symbols[i]
        
        # Decision-directed phase
        for i in range(n_train, n_total):
            x_ff = rx_signal[i-ff_length+1:i+1][::-1]
            y_ff = np.dot(w_ff, x_ff)
            y_fb = np.dot(w_fb, decisions)
            
            y = y_ff - y_fb
            equalized[i] = y
            
            # Make hard decision
            decision = Equalizer._qpsk_decision(y)
            
            # Update decision buffer
            decisions = np.roll(decisions, 1)
            decisions[0] = decision
        
        return equalized
    
    @staticmethod
    def _qpsk_decision(symbol):
        """Hard decision for QPSK"""
        if np.real(symbol) >= 0 and np.imag(symbol) >= 0:
            return (1 + 1j) / np.sqrt(2)
        elif np.real(symbol) < 0 and np.imag(symbol) >= 0:
            return (-1 + 1j) / np.sqrt(2)
        elif np.real(symbol) < 0 and np.imag(symbol) < 0:
            return (-1 - 1j) / np.sqrt(2)
        else:
            return (1 - 1j) / np.sqrt(2)