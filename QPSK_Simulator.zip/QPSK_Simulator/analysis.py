"""
Performance Analysis Tools
"""
import numpy as np
from qpsk_modem import QPSKModem
from channel import Channel

class PerformanceAnalyzer:
    """BER analysis and performance metrics"""
    
    def __init__(self, modem):
        """
        Initialize analyzer
        
        Args:
            modem: QPSKModem instance
        """
        self.modem = modem
    
    def ber_vs_snr(self, snr_range, num_bits=100000):
        """
        Calculate BER vs SNR curve
        
        Args:
            snr_range: Array of SNR values in dB
            num_bits: Number of bits per SNR point
        
        Returns:
            ber_array: BER for each SNR
        """
        ber_array = np.zeros(len(snr_range))
        
        for i, snr in enumerate(snr_range):
            # Generate random bits
            tx_bits = np.random.randint(0, 2, num_bits)
            
            # Modulate
            tx_signal, _ = self.modem.modulate(tx_bits)
            
            # Add noise
            rx_signal = Channel.awgn(tx_signal, snr)
            
            # Demodulate
            rx_bits, _ = self.modem.demodulate(rx_signal)
            
            # Trim to same length
            min_len = min(len(tx_bits), len(rx_bits))
            tx_bits = tx_bits[:min_len]
            rx_bits = rx_bits[:min_len]
            
            # Calculate BER
            errors = np.sum(tx_bits != rx_bits)
            ber_array[i] = errors / min_len
            
            print(f"SNR = {snr:2d} dB: BER = {ber_array[i]:.6f} ({errors} errors)")
        
        return ber_array
    
    @staticmethod
    def theoretical_ber_qpsk(snr_db):
        """
        Theoretical BER for QPSK in AWGN
        
        Args:
            snr_db: SNR in dB (Eb/N0)
        
        Returns:
            Theoretical BER
        """
        from scipy.special import erfc
        
        snr_linear = 10**(snr_db / 10)
        ber = 0.5 * erfc(np.sqrt(snr_linear))
        
        return ber
    
    def evm_analysis(self, tx_symbols, rx_symbols):
        """
        Calculate Error Vector Magnitude
        
        Args:
            tx_symbols: Transmitted symbols
            rx_symbols: Received symbols
        
        Returns:
            EVM in percentage
        """
        min_len = min(len(tx_symbols), len(rx_symbols))
        tx_symbols = tx_symbols[:min_len]
        rx_symbols = rx_symbols[:min_len]
        
        error_vector = rx_symbols - tx_symbols
        evm = np.sqrt(np.mean(np.abs(error_vector)**2))
        evm_percent = (evm / np.sqrt(np.mean(np.abs(tx_symbols)**2))) * 100
        
        return evm_percent